FlatLaf Testing
===============

This sub-project contains small Swing applications used to develop and test
FlatLaf.
